%TF.GenerationSoftware,KiCad,Pcbnew,10.0.7*%
%TF.CreationDate,2026-10-22T17:00:42-07:00*%
%TF.ProjectId,homebound_tag,686f6d65-626f-4756-9e64-5f7461672e6b,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.7) date 2026-10-22 17:00:42*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.050000X-0.225000X-0.110000X0.225000X-0.110000X0.225000X0.110000X-0.225000X0.110000X0*%
%ADD11C,1.100000*%
G04 APERTURE END LIST*
D10*
%TO.C,U1*%
X99250000Y-99400000D03*
X99250000Y-99800000D03*
X99250000Y-100200000D03*
X99250000Y-100600000D03*
X100750000Y-100600000D03*
X100750000Y-100200000D03*
X100750000Y-99800000D03*
X100750000Y-99400000D03*
%TD*%
D11*
%TO.C,*%
X98500000Y-101200000D03*
%TD*%
M02*
